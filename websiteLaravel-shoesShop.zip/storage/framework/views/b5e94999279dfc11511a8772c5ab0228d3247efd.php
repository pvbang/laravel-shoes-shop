

<?php $__env->startSection('content'); ?>

    <div class="card mb-3 shadow-5" style="background-color: #EEEEEE">
        <div class="card-body" style="margin-top:40px">
            <center>
                <h3 class="card-title" style="text-transform: uppercase;">SẢN PHẨM <?php echo e($giay['ten_giay']); ?></h3>
            </center>
        </div>
        <br>
    </div>

    <div class="container">
        <br>
        <nav aria-label="breadcrumb">
            <div class="row">
                <div class="col-md-7">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/trang-chu">Trang chủ</a></li>
                        <li class="breadcrumb-item"><a href="/cua-hang">Cửa hàng</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($giay['ten_giay']); ?></li>
                    </ol>
                    <br>
                </div>
                <?php $__currentLoopData = $gio_hangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $giohang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($giohang['ten_giay'] == $giay['ten_giay']): ?>
                        <div class="col-md-5">
                            <div class="alert alert-success" role="alert">
                                <i class="fas fa-check-circle"></i>&ensp;Sản phẩm này đã được thêm vào giỏ hàng của bạn!
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </nav>

        <div class="row">
            <div class="card mb-3">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="/storage/images/<?php echo e($giay['hinh_anh_1']); ?>" alt="..." class="img-fluid rounded-start" />
                        
                        <div class="row ">
                            <?php if($giay['hinh_anh_2']): ?>
                                <div class="col border ripple"><img src="/storage/images/<?php echo e($giay['hinh_anh_2']); ?>"
                                        alt="..." class="img-fluid rounded-start" /></div>
                            <?php else: ?> <div class="col border ripple"><img src="/storage/images/<?php echo e($giay['hinh_anh_1']); ?>"
                                        alt="..." class="img-fluid rounded-start" /></div>
                            <?php endif; ?>
                            <?php if($giay['hinh_anh_3']): ?>
                                <div class="col ripple"><img src="/storage/images/<?php echo e($giay['hinh_anh_3']); ?>" alt="..."
                                        class="img-fluid rounded-start" /></div>
                            <?php else: ?> <div class="col ripple"><img src="/storage/images/<?php echo e($giay['hinh_anh_1']); ?>"
                                        alt="..." class="img-fluid rounded-start" /></div>
                            <?php endif; ?>
                            <?php if($giay['hinh_anh_4']): ?>
                                <div class="col ripple"><img src="/storage/images/<?php echo e($giay['hinh_anh_4']); ?>" alt="..."
                                        class="img-fluid rounded-start" /></div>
                            <?php else: ?> <div class="col ripple"><img src="/storage/images/<?php echo e($giay['hinh_anh_1']); ?>"
                                        alt="..." class="img-fluid rounded-start" /></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <div class="float-end">
                                <script>
                                    $(function() {
                                        $("#RateDanhGia").rateYo({
                                            starWidth: "20px",
                                            ratedFill: "#16B5EA",
                                            rating: <?php echo e($soluongdanhgia['danh_gia']); ?>,
                                            readOnly: true,
                                        });
                                    });
                                </script>

                                <small class="text-muted float-end">( <?php echo e($soluongdanhgia['count_danh_gia']); ?> Đánh giá
                                    )</small>
                                <div id="RateDanhGia" class="float-end text-info"></div>
                            </div>
                            <h3 class="card-title" style="text-transform: uppercase;"><?php echo e($giay['ten_giay']); ?></h3>

                            <h4 class="card-text text-success">
                                <?php if($km = 0): ?><?php endif; ?>
                                <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($khuyenmai['ten_khuyen_mai'] == $giay['ten_khuyen_mai']): ?>
                                        <?php $km = sprintf('%d', $giay['don_gia'] * 0.01 * $khuyenmai['gia_tri_khuyen_mai']) ?>
                                        <?php if($gtkm = $khuyenmai['gia_tri_khuyen_mai']): ?><?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <b><?php echo e(number_format($giay['don_gia'] - $km, 0, ',', ',')); ?> VNĐ</b>
                                <?php if($km != 0): ?><del class="card-text text-danger"><?php echo e(number_format($giay['don_gia'], 0, ',', ',')); ?> VNĐ</del><?php endif; ?>
                            </h4>

                            <br>
                            <p class="card-text"><b>Mô tả:</b><?php echo $giay['mo_ta']; ?></p>
                            <p class="card-text"><b>Loại giày:</b> <?php echo e($giay['ten_loai_giay']); ?>&emsp;<i
                                    class="fab fa-squarespace"></i>&emsp; <b>Thương hiệu:</b>
                                <?php echo e($giay['ten_thuong_hieu']); ?>

                            </p>

                            <p class="card-text">
                                <small class="text-muted"></small>
                            </p>


                            <a href="/cua-hang/san-pham=<?php echo e($giay['id_giay']); ?>/them" type="button" class="btn btn-info"
                                style="margin-top: 10px"
                                data-url="<?php echo e(route('them-vao-gio-hang', ['id' => $giay['id_giay']])); ?>">
                                <i class="far fa-heart"></i>
                                &ensp;Thêm vào giỏ hàng
                            </a>
                            <a type="button" href="#ex2-tabs-1" class="btn btn-light">Chi tiết</a>


                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>
        <div class="row">
            <div class="card mb-3">
                <!-- Tabs navs -->
                <div class="container">
                    <ul class="nav nav-tabs nav-fill mb-3" id="ex1" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="ex2-tab-1" data-mdb-toggle="tab" href="#ex2-tabs-1" role="tab"
                                aria-controls="ex2-tabs-1" aria-selected="true">Mô tả sản phẩm</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="ex2-tab-2" data-mdb-toggle="tab" href="#ex2-tabs-2" role="tab"
                                aria-controls="ex2-tabs-2" aria-selected="false">Chi tiết sản phẩm</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="ex2-tab-3" data-mdb-toggle="tab" href="#ex2-tabs-3" role="tab"
                                aria-controls="ex2-tabs-3" aria-selected="false">Đánh giá</a>
                        </li>
                    </ul>
                    <!-- Tabs navs -->

                    <!-- Tabs content -->

                    <div class="tab-content" id="ex2-content">
                        <div class="tab-pane fade show active" id="ex2-tabs-1" role="tabpanel" aria-labelledby="ex2-tab-1">
                            <br>
                            <?php echo $giay['mo_ta']; ?><br>
                            <p><b>Ngày ra mắt: </b>Ngày 11 tháng 11 năm 2021</p>
                            <p><b>Thiết kế: </b>Yeezy 350</p>
                            <p><b>Mã sản phẩm: </b><?php echo e($giay['id_giay']); ?></p>
                            <br>
                        </div>
                        <div class="tab-pane fade" id="ex2-tabs-2" role="tabpanel" aria-labelledby="ex2-tab-2">
                            <br>
                            <p>✔️ <b>Mã giày: </b><?php echo e($giay['id_giay']); ?></p>
                            <p>✔️ <b>Tên giày: </b><?php echo e($giay['ten_giay']); ?></p>
                            <p>✔️ <b>Loại giày: </b><?php echo e($giay['ten_loai_giay']); ?></p>
                            <p>✔️ <b>Thương hiệu: </b><?php echo e($giay['ten_thuong_hieu']); ?></p>
                            <p>✔️ <b>Giá gốc: </b><?php echo e(number_format($giay['don_gia'])); ?> VNĐ</p>
                            <p>✔️ <b>Số lượng còn lại: </b><?php echo e($giay['so_luong']); ?></p>
                            <p>✔️ <b>Khuyến mãi: </b><?php echo e($giay['ten_khuyen_mai']); ?> (-<?php echo e($gtkm); ?>%)</p>
                            <p>✔️ <b>Đánh giá: </b><?php echo e($giay['danh_gia']); ?></p>
                            <br>
                        </div>
                        <div class="tab-pane fade" id="ex2-tabs-3" role="tabpanel" aria-labelledby="ex2-tab-3">
                            <?php
                                $checkk = 0;
                            ?>


                            <div class="row">

                                <div class="col-md-6">
                                    <br>
                                    <h5 class="card-title" style="margin-bottom:20px">ĐÁNH GIÁ</h5>

                                    <?php $__currentLoopData = $danhgias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $danhgia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($danhgia->id_user > 4): ?>
                                            <?php
                                                $ok = rand(1, 4);
                                            ?>
                                        <?php else: ?>
                                            <?php
                                                $ok = $danhgia->id_user;
                                            ?>
                                        <?php endif; ?>

                                        <div class="row">
                                            <div class="col-1">
                                                <img class="img-profile rounded-circle" height="40" width="40"
                                                    src="/images1/logo-user-<?php echo e($ok-1); ?>.png">
                                            </div>
                                            <div class="col-10">
                                                <small><?php echo e($danhgia->ten_danh_gia); ?></small>
                                                <small class="float-end"><?php echo e($danhgia->updated_at); ?></small>
                                                <br>
                                                <p><?php echo e($danhgia->danh_gia_binh_luan); ?></p>
                                            </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="pagination pagination-circle justify-content-end">
                                        <center><?php echo e($danhgias->links()); ?></center>
                                    </div>

                                    
                                </div>
                                <?php $__currentLoopData = $danh_gias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $danh_gia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($danh_gia['ten_giay'] == $giay['ten_giay']): ?>
                                        <?php $checkk = 1; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if($checkk == 1): ?>
                                    <div class="col-md-6">
                                        <br>
                                        <h5 class="float-start">ĐÁNH GIÁ SẢN PHẨM NÀY</h5>

                                        <div id="rateYo" class=" float-end text-info"></div><br><br>
                                        <form action="/cua-hang/san-pham=<?php echo e($giay['id_giay']); ?>/danh-gia" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" class="form-control" name="danh_gia" id="danh_gia"
                                                value="4.5">
                                            <input type="hidden" class="form-control" name="id_user"
                                                value="<?php echo e($data['id']); ?>">
                                            <input type="hidden" class="form-control" name="id_giay"
                                                value="<?php echo e($giay['id_giay']); ?>">

                                            <div class="form-outline mb-4">
                                                <input type="input" class="form-control" name="ten_danh_gia" required
                                                    value="<?php echo e($data['ten_nguoi_dung']); ?>" />
                                                <label class="form-label">Tên</label>
                                            </div>
                                            <div class="form-outline">
                                                <textarea class="form-control" name="danh_gia_binh_luan"
                                                    rows="4"></textarea>
                                                <label class="form-label">Bình luận đánh giá</label>
                                            </div>
                                            <br>
                                            <button type="submit" class="btn btn-info float-end">Gửi đánh giá</button>
                                        </form>

                                    </div>
                                <?php endif; ?>
                                

                                <?php if($checkk == 0): ?>
                                    <div class="col-md-6">
                                        <br><br>
                                        <center>
                                            <p class="text-danger">Bạn cần mua sản phẩm này mới có thể đánh giá!</p>
                                        </center>
                                        <br>
                                    </div>
                                <?php endif; ?>

                            </div>
                            <br>



                        </div>
                    </div>
                    <!-- Tabs content -->
                </div>
            </div>
        </div>

        <br>
        <div class="card mb-3 shadow-1">
            <div class="card-body" style="margin-top:40px">
                <center>
                    <h3 class="card-title" style="text-transform: uppercase;">SẢN PHẨM TƯƠNG TỰ</h3>
                </center>
            </div>
            <br>
        </div>
        <br>
        <div id="carouselExampleControls" class="carousel slide" data-mdb-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="row">
                        <?php if($dem = 1): ?><?php endif; ?>
                        <?php $__currentLoopData = $giaytuongtus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giaytuongtu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dem < 5): ?>
                                <div class="col-md-3">
                                    <div class="card" style="margin-bottom: 25px">
                                        <a href="/cua-hang/san-pham=<?php echo e($giaytuongtu->id_giay); ?>">
                                            <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
                                                <center><img src="/storage/images/<?php echo e($giaytuongtu->hinh_anh_1); ?>"
                                                        class="img-fluid" style="height:306px; width:306px" /></center>
                                                <div class="mask"
                                                    style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                            </div>
                                            <div class="card-body">
                                                <center>
                                                    <h4 class="card-title"><?php echo e($giaytuongtu->ten_giay); ?></h4>
                                                    <p class="card-text text-success">
                                                        <?php if($km = 0): ?><?php endif; ?>
                                                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($khuyenmai['ten_khuyen_mai'] == $giaytuongtu->ten_khuyen_mai): ?>
                                                                <?php if($km = sprintf('%d', $giaytuongtu->don_gia * 0.01 * $khuyenmai['gia_tri_khuyen_mai'])): ?><?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <b><?php echo e(number_format($giaytuongtu->don_gia - $km, 0, ',', ',')); ?>

                                                            VNĐ</b>
                                                        <del class="card-text text-danger"><?php echo e(number_format($giaytuongtu->don_gia, 0, ',', ',')); ?>

                                                            VNĐ </del>
                                                    </p>
                                                </center>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php if($dem = $dem + 1): ?><?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="row">
                        <?php if($dem = 1): ?><?php endif; ?>
                        <?php $__currentLoopData = $giaytuongtus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giaytuongtu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dem < 5 && $giaytuongtu->id_giay > 5): ?>
                                <div class="col-md-3">
                                    <div class="card" style="margin-bottom: 25px">
                                        <a href="/cua-hang/san-pham=<?php echo e($giaytuongtu->id_giay); ?>">
                                            <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
                                                <center><img src="/storage/images/<?php echo e($giaytuongtu->hinh_anh_1); ?>"
                                                        class="img-fluid" style="height:306px; width:306px" />
                                                </center>
                                                <div class="mask"
                                                    style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                            </div>
                                            <div class="card-body">
                                                <center>
                                                    <h4 class="card-title"><?php echo e($giaytuongtu->ten_giay); ?></h4>
                                                    <p class="card-text text-success">
                                                        <?php if($km = 0): ?><?php endif; ?>
                                                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($khuyenmai['ten_khuyen_mai'] == $giaytuongtu->ten_khuyen_mai): ?>
                                                                <?php if($km = sprintf('%d', $giaytuongtu->don_gia * 0.01 * $khuyenmai['gia_tri_khuyen_mai'])): ?><?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <b><?php echo e(number_format($giaytuongtu->don_gia - $km, 0, ',', ',')); ?>

                                                            VNĐ</b>
                                                        <del class="card-text text-danger"><?php echo e(number_format($giaytuongtu->don_gia, 0, ',', ',')); ?>

                                                            VNĐ </del>
                                                    </p>
                                                </center>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php if($dem = $dem + 1): ?><?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="carousel-item">
                    <div class="row">
                        <?php if($dem = 1): ?><?php endif; ?>
                        <?php $__currentLoopData = $giaytuongtus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giaytuongtu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dem < 5 && $giaytuongtu->id_giay > 9): ?>
                                <div class="col-md-3">
                                    <div class="card" style="margin-bottom: 25px">
                                        <a href="/cua-hang/san-pham=<?php echo e($giaytuongtu->id_giay); ?>">
                                            <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
                                                <center><img src="/storage/images/<?php echo e($giaytuongtu->hinh_anh_1); ?>"
                                                        class="img-fluid" style="height:306px; width:306px" />
                                                </center>
                                                <div class="mask"
                                                    style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                            </div>
                                            <div class="card-body">
                                                <center>
                                                    <h4 class="card-title"><?php echo e($giaytuongtu->ten_giay); ?></h4>
                                                    <p class="card-text text-success">
                                                        <?php if($km = 0): ?><?php endif; ?>
                                                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($khuyenmai['ten_khuyen_mai'] == $giaytuongtu->ten_khuyen_mai): ?>
                                                                <?php if($km = sprintf('%d', $giaytuongtu->don_gia * 0.01 * $khuyenmai['gia_tri_khuyen_mai'])): ?><?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <b><?php echo e(number_format($giaytuongtu->don_gia - $km)); ?> VNĐ</b>
                                                        <del class="card-text text-danger"><?php echo e(number_format($giaytuongtu->don_gia)); ?>

                                                            VNĐ </del>
                                                    </p>
                                                </center>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php if($dem = $dem + 1): ?><?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-mdb-target="#carouselExampleControls"
                data-mdb-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-mdb-target="#carouselExampleControls"
                data-mdb-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>

        </div>


    </div>

    <br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\websiteLaravel-shoesShop\resources\views/app/cuahang/sanpham.blade.php ENDPATH**/ ?>