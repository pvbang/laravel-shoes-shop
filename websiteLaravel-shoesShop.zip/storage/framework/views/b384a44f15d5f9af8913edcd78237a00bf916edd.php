

<?php $__env->startSection('content'); ?>

    <?php switch($route):
        case ('trang-chu'): ?>
            <?php echo $__env->make('app.app.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('app.app.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
    
        <?php case ('cua-hang'): ?>
            <?php echo $__env->make('app.cuahang.cuahang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            
        <?php case ('san-pham'): ?>

            <?php echo $__env->make('app.cuahang.sanpham', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        
        <?php case ('thanh-toan'): ?>
            <?php echo $__env->make('app.thanhtoan.thanhtoan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ('gio-hang'): ?>
            <?php echo $__env->make('app.giohang.giohang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ('gioi-thieu'): ?>
            <?php echo $__env->make('app.app.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('app.gioithieu.gioithieu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ('tai-khoan'): ?>
            <?php echo $__env->make('app.taikhoan.taikhoan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php default: ?>
            <?php echo $__env->make('app.app.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
    <?php endswitch; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\websiteLaravel-shoesShop\resources\views/index.blade.php ENDPATH**/ ?>