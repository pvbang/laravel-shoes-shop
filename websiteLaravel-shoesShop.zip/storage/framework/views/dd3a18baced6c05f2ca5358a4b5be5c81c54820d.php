<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>PVB SHOP</title>

	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL('images1/icon-logo.png')); ?>">

	<link href="<?php echo e(URL('css/sb-admin-2.min.css')); ?>" rel="stylesheet" type="text/css">
	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

	<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet"/>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.css" rel="stylesheet"/>

	<link href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css" rel="stylesheet"/>

	<script src="<?php echo e(URL('js/jquery.dataTables.min.js')); ?>"></script>
	<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>

	<script src="https://cdn.ckeditor.com/ckeditor5/31.0.0/classic/ckeditor.js"></script>
	
</head>
<body id="page-top">
	<div id="wrapper">

		<?php echo $__env->make('admin.app.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div id="content-wrapper" class="d-flex flex-column">
			<div id="content">
				<?php echo $__env->make('admin.app.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<div class="container-fluid">
                    
					<?php echo $__env->yieldContent('admin_content'); ?>
					
				</div>
			</div>

			<?php echo $__env->make('admin.app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>


	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.js"></script>
	<script src="<?php echo e(URL('js/sb-admin-2.min.js')); ?>"></script>
	<script src="<?php echo e(URL('js/bootstrap.bundle.min.js')); ?>"></script>
	<script>
    ClassicEditor
        .create( document.querySelector( '#ckediter' ) )
        .catch( error => {
            console.error( error );
        } );
	</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\websiteLaravel-shoesShop\resources\views/admin/index.blade.php ENDPATH**/ ?>