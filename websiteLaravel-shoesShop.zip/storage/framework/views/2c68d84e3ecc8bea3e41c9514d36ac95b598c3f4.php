

<?php $__env->startSection('admin_content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h4 class="" style="margin-top: 10px">
            <strong>SỬA GIÀY</strong>&ensp;
            <i class="fas fa-list"></i>
        </h4>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <form action="/admin/giay/sua" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <br>
                <input type="hidden" class="form-control" name="id_giay" value="<?php echo e($giay['id_giay']); ?>"/>

                <div class="form-outline mb-4">
                    <input type="input" class="form-control" name="ten_giay" value="<?php echo e($giay['ten_giay']); ?>" required />
                    <label class="form-label">Tên giày</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="input" class="form-control" name="ten_loai_giay" list="loai_giay" autocomplete="off" value="<?php echo e($giay['ten_loai_giay']); ?>" required />
                    <label class="form-label">Loại giày</label>
                    <datalist id="loai_giay">
                        <?php $__currentLoopData = $loaigiays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loaigiay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($loaigiay['ten_loai_giay']); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                </div>

                <div class="form-outline mb-4">
                    <input type="input" class="form-control" name="ten_thuong_hieu" list="thuong_hieu" autocomplete="off" value="<?php echo e($giay['ten_thuong_hieu']); ?>" required />
                    <label class="form-label">Thương hiệu</label>
                    <datalist id="thuong_hieu">
                        <?php $__currentLoopData = $thuonghieus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thuonghieu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($thuonghieu['ten_thuong_hieu']); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                </div>

                <label class="form-label" for="ckediter"><b>Mô tả:</b></label>
                <div class="form-outline mb-4">
                    <textarea type="input" class="form-control" id="ckediter" name="mo_ta" ><?php echo e($giay['mo_ta']); ?></textarea>
                </div>

                <div class="form-outline mb-4">
                    <input type="input" class="form-control" name="don_gia" value="<?php echo e($giay['don_gia']); ?>" required />
                    <label class="form-label">Đơn giá</label>
                </div>

                <div class="form-outline mb-4">
                    <input type="input" class="form-control" name="so_luong" value="<?php echo e($giay['so_luong']); ?>" required />
                    <label class="form-label">Số lượng</label>
                </div>

                <label class="form-label"><b>Hình ảnh 1:</b></label>
                <div class="form-outline mb-4">
                    <input type="file" class="form-control" name="hinh_anh_1" value="<?php echo e($giay['hinh_anh_1']); ?>">
                </div>

                <label class="form-label"><b>Hình ảnh 2:</b></label>
                <div class="form-outline mb-4">
                    <input type="file" class="form-control" name="hinh_anh_2" value="<?php echo e($giay['hinh_anh_2']); ?>" />
                </div>

                <label class="form-label"><b>Hình ảnh 3:</b></label>
                <div class="form-outline mb-4">
                    <input type="file" class="form-control" name="hinh_anh_3" value="<?php echo e($giay['hinh_anh_3']); ?>" />
                </div>

                <label class="form-label"><b>Hình ảnh 4:</b></label>
                <div class="form-outline mb-4">
                    <input type="file" class="form-control" name="hinh_anh_4" value="<?php echo e($giay['hinh_anh_4']); ?>" />
                </div>

                <div class="form-outline mb-4">
                    <input type="input" class="form-control" name="ten_khuyen_mai" list="khuyen_mai" autocomplete="off" value="<?php echo e($giay['ten_khuyen_mai']); ?>"  />
                    <label class="form-label">Khuyễn mãi</label>
                    <datalist id="khuyen_mai">
                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($khuyenmai['ten_khuyen_mai']); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                </div>

                <button type="submit" class="btn btn-primary">Sửa</button>
                <a href="/admin/giay" type="button" class="btn btn-info">Quay lại</a>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\websiteLaravel-shoesShop\resources\views/admin/giay/sua.blade.php ENDPATH**/ ?>