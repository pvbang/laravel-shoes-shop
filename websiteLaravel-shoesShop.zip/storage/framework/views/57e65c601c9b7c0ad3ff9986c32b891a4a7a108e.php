

<?php $__env->startSection('content'); ?>

<div class="card mb-3 shadow-5" style="background-color: #EEEEEE">
    <div class="card-body" style="margin-top:40px">
        <center>
            <h3 class="card-title">CỬA HÀNG</h3>
        </center>
    </div>
    <br>
</div>

<div class="container">
    <br>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/trang-chu">Trang chủ</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cửa hàng</li>
        </ol>
    </nav>

    <br>
    <div class="row">
        <div class="col-xl-3">
            <div class="card">
                <div class="card-header" style="margin-top:10px">
                    <center>
                        <h5>DANH MỤC</h5>
                    </center>
                </div>
                <div class="card-body">
                    <div class="accordion accordion-flush" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingOne">
                                <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                                    data-mdb-target="#flush-collapseOne" aria-expanded="false"
                                    aria-controls="flush-collapseOne">
                                    <i class="fas fa-shoe-prints"></i>&nbsp; LOẠI GIÀY
                                </button>
                            </h2>
                            <div id="flush-collapseOne" class="accordion-collapse collapse"
                                aria-labelledby="flush-headingOne" data-mdb-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <ul class="list-group list-group-flush">
                                        <?php $__currentLoopData = $loaigiays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loaigiay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/loaigiay=<?php echo e($loaigiay['ten_loai_giay']); ?>"
                                                class="text-dark"><?php echo e($loaigiay['ten_loai_giay']); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingTwo">
                                <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                                    data-mdb-target="#flush-collapseTwo" aria-expanded="false"
                                    aria-controls="flush-collapseTwo">
                                    <i class="fas fa-trademark"></i>&nbsp; THƯƠNG HIỆU
                                </button>
                            </h2>
                            <div id="flush-collapseTwo" class="accordion-collapse collapse"
                                aria-labelledby="flush-headingTwo" data-mdb-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <ul class="list-group list-group-flush">
                                        <?php $__currentLoopData = $thuonghieus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thuonghieu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/thuonghieu=<?php echo e($thuonghieu['ten_thuong_hieu']); ?>"
                                                class="text-dark"><?php echo e($thuonghieu['ten_thuong_hieu']); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingThree">
                                <button class="accordion-button collapsed" type="button" data-mdb-toggle="collapse"
                                    data-mdb-target="#flush-collapseThree" aria-expanded="false"
                                    aria-controls="flush-collapseThree">
                                    <i class="fas fa-dollar-sign"></i><i class="fas fa-dollar-sign"></i>&nbsp; GIÁ CẢ
                                </button>
                            </h2>
                            <div id="flush-collapseThree" class="accordion-collapse collapse"
                                aria-labelledby="flush-headingThree" data-mdb-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=0-300000" class="text-dark">
                                                < 300,000 VNĐ</a>
                                        </li>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=300000-500000" class="text-dark">300,000 ~ 500,000
                                                VNĐ</a>
                                        </li>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=500000-700000" class="text-dark">500,000 ~ 700,000
                                                VNĐ</a>
                                        </li>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=700000-1000000" class="text-dark">700,000 ~
                                                1,000,000 VNĐ</a>
                                        </li>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=1000000-1500000" class="text-dark">1,000,000 ~
                                                1,500,000 VNĐ</a>
                                        </li>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=1500000-2000000" class="text-dark">1,500,000 ~
                                                2,000,000 VNĐ</a>
                                        </li>
                                        <li class="list-group-item">
                                            <a href="/cua-hang/gia=2000000-100000000" class="text-dark">> 2,000,000 VNĐ</a>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br>


        </div>


        <div class="col-xl-9">
            <div class="row">

                <?php $__currentLoopData = $giays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($timloaigiay != ''): ?>
                <?php if($giay->ten_loai_giay == $timloaigiay): ?>
                <div class="col-md-4">
                    <div class="card" style="margin-bottom: 25px">
                        <a href="/cua-hang/san-pham=<?php echo e($giay->id_giay); ?>">
                            <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light" >
                                <center><img src="/storage/images/<?php echo e($giay->hinh_anh_1); ?>" class="img-fluid" style="height:306px; width:306px"/></center>
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                            </div>
                            <div class="card-body">
                                <center>
                                    <h4 class="card-title"><?php echo e($giay->ten_giay); ?></h4>
                                    <p class="card-text text-success">
                                        <?php if($km = 0): ?><?php endif; ?>
                                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($khuyenmai['ten_khuyen_mai'] == $giay->ten_khuyen_mai): ?>
                                        <?php if($km = sprintf('%d', $giay->don_gia * 0.01 *
                                        $khuyenmai['gia_tri_khuyen_mai'])): ?><?php endif; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <b><?php echo e(number_format($giay->don_gia - $km, 0, ',', ',')); ?> VNĐ</b>
                                        <?php if($km != 0): ?><del
                                            class="card-text text-danger"><?php echo e(number_format($giay->don_gia, 0, ',', ',')); ?>

                                            VNĐ </del><?php endif; ?>
                                    </p>
                                </center>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                <?php if($timthuonghieu != ''): ?>
                <?php if($giay->ten_thuong_hieu == $timthuonghieu): ?>
                <div class="col-md-4">
                    <div class="card" style="margin-bottom: 25px">
                        <a href="/cua-hang/san-pham=<?php echo e($giay->id_giay); ?>">
                            <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light" >
                                <center><img src="/storage/images/<?php echo e($giay->hinh_anh_1); ?>" class="img-fluid" style="height:306px; width:306px"/></center>
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                            </div>
                            <div class="card-body">
                                <center>
                                    <h4 class="card-title"><?php echo e($giay->ten_giay); ?></h4>
                                    <p class="card-text text-success">
                                        <?php if($km = 0): ?><?php endif; ?>
                                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($khuyenmai['ten_khuyen_mai'] == $giay->ten_khuyen_mai): ?>
                                        <?php if($km = sprintf('%d', $giay->don_gia * 0.01 *
                                        $khuyenmai['gia_tri_khuyen_mai'])): ?><?php endif; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <b><?php echo e(number_format($giay->don_gia - $km, 0, ',', ',')); ?> VNĐ</b>
                                        <?php if($km != 0): ?><del
                                            class="card-text text-danger"><?php echo e(number_format($giay->don_gia, 0, ',', ',')); ?>

                                            VNĐ </del><?php endif; ?>
                                    </p>
                                </center>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                <?php if(($timloaigiay=='') && ($timthuonghieu=='')): ?>
                <div class="col-md-4" >
                    <div class="card" style="margin-bottom: 25px">
                        <a href="/cua-hang/san-pham=<?php echo e($giay->id_giay); ?>">
                            <div class="bg-image hover-overlay ripple" data-mdb-ripple-color="light">
                                <center><img src="/storage/images/<?php echo e($giay->hinh_anh_1); ?>" class="img-fluid" style="height:306px; width:306px"/></center>
                                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                            </div>
                            <div class="card-body">
                                <center>
                                    <h4 class="card-title"><?php echo e($giay->ten_giay); ?></h4>
                                    <p class="card-text text-success">
                                        <?php if($km = 0): ?><?php endif; ?>
                                        <?php $__currentLoopData = $khuyenmais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($khuyenmai['ten_khuyen_mai'] == $giay->ten_khuyen_mai): ?>
                                        <?php if($km = sprintf('%d', $giay->don_gia * 0.01 *
                                        $khuyenmai['gia_tri_khuyen_mai'])): ?><?php endif; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <b><?php echo e(number_format($giay->don_gia - $km, 0, ',', ',')); ?> VNĐ</b>
                                        <?php if($km != 0): ?><del
                                            class="card-text text-danger"><?php echo e(number_format($giay->don_gia, 0, ',', ',')); ?>

                                            VNĐ </del><?php endif; ?>
                                    </p>
                                </center>
                            </div>
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <br>
            <div class="pagination pagination-circle justify-content-end">
                <center><?php echo e($giays->links()); ?></center>
            </div>

        </div>
    </div>

    <br>
    <br>
    <br>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\websiteLaravel-shoesShop\resources\views/app/cuahang/cuahang.blade.php ENDPATH**/ ?>