<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
             © 2021 Bản quyền thuộc về:
             <a class="text-info" href="/ ">PVB SHOP - Phan Văn Bằng</a>
        </div>
    </div>
 </footer>
 